"""Flask backend for the AI-Based Emergency Resource Allocation System.

Run:  python app.py      ->  http://127.0.0.1:5000
"""
import logging
from contextlib import closing

from flask import Flask, jsonify, render_template, request

import allocator
import database as db
import severity_model

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s: %(message)s")

SEVERITY_ORDER_SQL = (
    "CASE severity WHEN 'Critical' THEN 4 WHEN 'High' THEN 3 WHEN 'Medium' THEN 2 ELSE 1 END"
)


def validate_incident(payload):
    """Data Collection module: validate required fields. Returns (clean, error)."""
    try:
        emergency_type = str(payload.get("emergency_type", "")).strip().title()
        if emergency_type not in severity_model.EMERGENCY_TYPES:
            return None, f"emergency_type must be one of {severity_model.EMERGENCY_TYPES}"
        latitude = float(payload.get("latitude"))
        longitude = float(payload.get("longitude"))
        casualties = int(payload.get("casualties", 0) or 0)
    except (TypeError, ValueError):
        return None, "latitude, longitude and casualties must be valid numbers"
    if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
        return None, "latitude/longitude out of range"
    if casualties < 0:
        return None, "casualties cannot be negative"
    description = str(payload.get("description", "") or "").strip()[:500]
    return {
        "emergency_type": emergency_type,
        "latitude": latitude,
        "longitude": longitude,
        "casualties": casualties,
        "description": description,
    }, None


def create_app(seed=True):
    app = Flask(__name__)
    db.init_db(seed=seed)
    severity_model.get_model()  # load / train once at startup

    @app.get("/")
    def index():
        return render_template(
            "index.html",
            emergency_types=severity_model.EMERGENCY_TYPES,
            resource_types=allocator.RESOURCE_TYPES,
        )

    @app.get("/api/dashboard")
    def dashboard():
        with closing(db.get_conn()) as conn:
            pending = [dict(r) for r in conn.execute(
                f"SELECT * FROM incidents WHERE status = 'Pending' "
                f"ORDER BY {SEVERITY_ORDER_SQL} DESC, casualties DESC, reported_time ASC"
            )]
            resources = [dict(r) for r in conn.execute("SELECT * FROM resources ORDER BY resource_id")]
            allocations = [dict(r) for r in conn.execute(
                "SELECT a.allocation_id, a.incident_id, a.resource_id, a.distance_km, a.assigned_time,"
                " a.status, a.message, i.emergency_type, i.severity, r.resource_type"
                " FROM allocations a"
                " JOIN incidents i ON i.incident_id = a.incident_id"
                " JOIN resources r ON r.resource_id = a.resource_id"
                " ORDER BY a.allocation_id DESC LIMIT 10"
            )]
        stats = {
            "pending_incidents": len(pending),
            "available_resources": sum(1 for r in resources if r["status"] == "Available"),
            "recent_allocations": len(allocations),
        }
        return jsonify(stats=stats, pending=pending, resources=resources, allocations=allocations)

    @app.post("/api/predict")
    def predict():
        clean, error = validate_incident({**(request.get_json(silent=True) or {}), "latitude": 0, "longitude": 0})
        if error:
            return jsonify(error=error), 400
        severity, confidence = severity_model.predict_severity(
            clean["emergency_type"], clean["casualties"], clean["description"]
        )
        return jsonify(severity=severity, confidence=round(confidence, 3))

    @app.post("/api/incidents")
    def report_incident():
        clean, error = validate_incident(request.get_json(silent=True) or {})
        if error:
            return jsonify(error=error), 400
        severity, confidence = severity_model.predict_severity(
            clean["emergency_type"], clean["casualties"], clean["description"]
        )
        with closing(db.get_conn()) as conn:
            incident_id = db.insert_incident(
                conn, clean["emergency_type"], clean["latitude"], clean["longitude"],
                clean["casualties"], clean["description"], severity,
            )
            new_allocations = allocator.run_allocation(conn)
        mine = next((a for a in new_allocations if a["incident_id"] == incident_id), None)
        return jsonify(
            incident_id=incident_id,
            severity=severity,
            confidence=round(confidence, 3),
            allocated=mine is not None,
            allocation=mine,
            alert=None if mine else "No suitable resource available - request queued as Pending.",
            other_allocations=[a for a in new_allocations if a["incident_id"] != incident_id],
        ), 201

    @app.post("/api/optimize")
    def optimize():
        with closing(db.get_conn()) as conn:
            results = allocator.run_allocation(conn)
        return jsonify(allocations=results, count=len(results))

    @app.post("/api/allocations/<int:allocation_id>/complete")
    def complete(allocation_id):
        with closing(db.get_conn()) as conn:
            results = allocator.complete_allocation(conn, allocation_id)
        if results is None:
            return jsonify(error="Active allocation not found"), 404
        return jsonify(released=True, new_allocations=results)

    @app.post("/api/resources")
    def add_resource():
        data = request.get_json(silent=True) or {}
        try:
            resource_id = str(data["resource_id"]).strip()
            resource_type = str(data["resource_type"]).strip().title()
            latitude, longitude = float(data["latitude"]), float(data["longitude"])
        except (KeyError, TypeError, ValueError):
            return jsonify(error="resource_id, resource_type, latitude, longitude are required"), 400
        if not resource_id or resource_type not in allocator.RESOURCE_TYPES:
            return jsonify(error=f"resource_type must be one of {allocator.RESOURCE_TYPES}"), 400
        with closing(db.get_conn()) as conn:
            try:
                db.insert_resource(conn, resource_id, resource_type, latitude, longitude)
            except Exception:
                return jsonify(error="resource_id already exists"), 409
            results = allocator.run_allocation(conn)  # a new free unit may serve pending incidents
        return jsonify(resource_id=resource_id, new_allocations=results), 201

    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000, debug=False)
