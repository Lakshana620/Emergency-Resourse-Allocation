"""SQLite database layer (Resource Availability Tracking + ER entities from Chapter 6.5).

SQLite is used so the project runs with zero setup. The same schema maps directly
to MySQL if you want to switch later.
"""
import os
import sqlite3
from datetime import datetime

DEFAULT_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "emergency.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents (
    incident_id    TEXT PRIMARY KEY,
    emergency_type TEXT NOT NULL,
    latitude       REAL NOT NULL,
    longitude      REAL NOT NULL,
    casualties     INTEGER NOT NULL DEFAULT 0,
    description    TEXT NOT NULL DEFAULT '',
    reported_time  TEXT NOT NULL,
    severity       TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'Pending'   -- Pending | Allocated | Resolved
);

CREATE TABLE IF NOT EXISTS resources (
    resource_id   TEXT PRIMARY KEY,
    resource_type TEXT NOT NULL,
    latitude      REAL NOT NULL,
    longitude     REAL NOT NULL,
    status        TEXT NOT NULL DEFAULT 'Available'  -- Available | Busy
);

CREATE TABLE IF NOT EXISTS allocations (
    allocation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id   TEXT NOT NULL REFERENCES incidents(incident_id),
    resource_id   TEXT NOT NULL REFERENCES resources(resource_id),
    distance_km   REAL NOT NULL,
    assigned_time TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'Active',    -- Active | Completed
    message       TEXT
);
"""

# Sample fleet around Coimbatore
SEED_RESOURCES = [
    ("AMB-01", "Ambulance", 11.0070, 76.9500),
    ("AMB-02", "Ambulance", 11.0300, 76.9900),
    ("AMB-03", "Ambulance", 10.9900, 76.9600),
    ("FIRE-01", "Fire Engine", 11.0168, 76.9558),
    ("FIRE-02", "Fire Engine", 11.0500, 77.0100),
    ("RESC-01", "Rescue Team", 11.0200, 76.9700),
    ("RESC-02", "Rescue Team", 10.9800, 77.0000),
    ("RELF-01", "Relief Truck", 11.0100, 76.9400),
]

# Sample pending incidents (mirrors the screenshot in Appendix D)
SEED_INCIDENTS = [
    ("INC00001", "Flood", 11.0300, 76.9400, 0, "water level rising, roads submerged", "High"),
    ("INC00002", "Flood", 10.9700, 77.0200, 1, "waterlogging, one person injured", "Medium"),
    ("INC00003", "Accident", 11.0000, 76.9800, 4, "bus collision, people trapped", "Critical"),
]


def db_path():
    return os.environ.get("EMERGENCY_DB", DEFAULT_DB)


def get_conn():
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    return conn


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def init_db(seed=True):
    conn = get_conn()
    try:
        conn.executescript(SCHEMA)
        if seed and conn.execute("SELECT COUNT(*) FROM resources").fetchone()[0] == 0:
            conn.executemany(
                "INSERT INTO resources(resource_id, resource_type, latitude, longitude) VALUES (?,?,?,?)",
                SEED_RESOURCES,
            )
            for inc_id, typ, lat, lon, cas, desc, sev in SEED_INCIDENTS:
                conn.execute(
                    "INSERT INTO incidents(incident_id, emergency_type, latitude, longitude, casualties,"
                    " description, reported_time, severity) VALUES (?,?,?,?,?,?,?,?)",
                    (inc_id, typ, lat, lon, cas, desc, now_str(), sev),
                )
        conn.commit()
    finally:
        conn.close()


def next_incident_id(conn):
    row = conn.execute(
        "SELECT MAX(CAST(SUBSTR(incident_id, 4) AS INTEGER)) FROM incidents WHERE incident_id LIKE 'INC%'"
    ).fetchone()
    return f"INC{(row[0] or 0) + 1:05d}"


def insert_incident(conn, emergency_type, latitude, longitude, casualties, description, severity):
    incident_id = next_incident_id(conn)
    conn.execute(
        "INSERT INTO incidents(incident_id, emergency_type, latitude, longitude, casualties,"
        " description, reported_time, severity) VALUES (?,?,?,?,?,?,?,?)",
        (incident_id, emergency_type, latitude, longitude, casualties, description, now_str(), severity),
    )
    conn.commit()
    return incident_id


def insert_resource(conn, resource_id, resource_type, latitude, longitude):
    conn.execute(
        "INSERT INTO resources(resource_id, resource_type, latitude, longitude) VALUES (?,?,?,?)",
        (resource_id, resource_type, latitude, longitude),
    )
    conn.commit()
