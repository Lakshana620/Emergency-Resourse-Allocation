const $ = (id) => document.getElementById(id);

const esc = (value) =>
    String(value).replace(/[&<>"']/g, (c) => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));

async function api(url, options = {}) {
    const res = await fetch(url, {
        method: options.method || "GET",
        headers: { "Content-Type": "application/json" },
        body: options.body ? JSON.stringify(options.body) : undefined,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");
    return data;
}

function showToast(message, kind = "") {
    const toast = $("toast");
    toast.textContent = message;
    toast.className = "toast " + kind;
    toast.hidden = false;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => (toast.hidden = true), 8000);
}

const sev = (s) => `<span class="sev-${esc(s).toLowerCase()}">${esc(s)}</span>`;
const loc = (r) => `${Number(r.latitude).toFixed(4)}, ${Number(r.longitude).toFixed(4)}`;
const emptyRow = (cols, text) => `<tr><td class="empty" colspan="${cols}">${text}</td></tr>`;

function render(data) {
    $("stat-pending").textContent = data.stats.pending_incidents;
    $("stat-available").textContent = data.stats.available_resources;
    $("stat-allocations").textContent = data.stats.recent_allocations;

    $("tbl-allocations").innerHTML = data.allocations.length
        ? data.allocations.map((a) => `
            <tr title="${esc(a.message || "")}">
                <td>${esc(a.incident_id)}</td>
                <td>${esc(a.emergency_type)}</td>
                <td>${sev(a.severity)}</td>
                <td>${esc(a.resource_id)}</td>
                <td>${esc(a.resource_type)}</td>
                <td>${Number(a.distance_km).toFixed(2)}</td>
                <td>${esc(a.status)}</td>
                <td>${a.status === "Active"
                    ? `<button class="small" data-complete="${a.allocation_id}">Mark complete</button>` : ""}</td>
            </tr>`).join("")
        : emptyRow(8, "No allocations yet.");

    $("tbl-pending").innerHTML = data.pending.length
        ? data.pending.map((i) => `
            <tr>
                <td>${esc(i.incident_id)}</td>
                <td>${esc(i.emergency_type)}</td>
                <td>${sev(i.severity)}</td>
                <td>${esc(i.casualties)}</td>
                <td>${loc(i)}</td>
            </tr>`).join("")
        : emptyRow(5, "No pending incidents.");

    $("tbl-resources").innerHTML = data.resources.map((r) => `
        <tr>
            <td>${esc(r.resource_id)}</td>
            <td>${esc(r.resource_type)}</td>
            <td class="status-${esc(r.status).toLowerCase()}">${esc(r.status)}</td>
            <td>${loc(r)}</td>
        </tr>`).join("");
}

async function refresh() {
    try {
        render(await api("/api/dashboard"));
    } catch (err) {
        showToast(err.message, "error");
    }
}

// --- Actions --------------------------------------------------------------

$("btn-optimize").addEventListener("click", async () => {
    try {
        const res = await api("/api/optimize", { method: "POST" });
        showToast(
            res.count ? `AI optimization assigned ${res.count} resource(s).`
                      : "No new allocations: nothing pending, or no suitable resource is free.",
            res.count ? "" : "alert"
        );
        refresh();
    } catch (err) {
        showToast(err.message, "error");
    }
});

$("tbl-allocations").addEventListener("click", async (event) => {
    const id = event.target.dataset.complete;
    if (!id) return;
    try {
        const res = await api(`/api/allocations/${id}/complete`, { method: "POST" });
        const n = res.new_allocations.length;
        showToast(`Response completed, resource released.` + (n ? ` ${n} pending incident(s) newly allocated.` : ""));
        refresh();
    } catch (err) {
        showToast(err.message, "error");
    }
});

// --- Report incident dialog -----------------------------------------------

const dialog = $("dlg-report");
const form = $("form-report");

$("btn-report").addEventListener("click", () => {
    updatePrediction();
    dialog.showModal();
});
$("btn-cancel").addEventListener("click", () => dialog.close());

function formPayload() {
    const f = new FormData(form);
    return Object.fromEntries(f.entries());
}

async function updatePrediction() {
    const p = formPayload();
    try {
        const res = await api("/api/predict", {
            method: "POST",
            body: { emergency_type: p.emergency_type, casualties: p.casualties, description: p.description },
        });
        $("predicted").className = "sev-" + res.severity.toLowerCase();
        $("predicted").textContent = `${res.severity} (${Math.round(res.confidence * 100)}% confidence)`;
    } catch (err) {
        $("predicted").className = "";
        $("predicted").textContent = "-";
    }
}

["emergency_type", "casualties", "description"].forEach((name) => {
    form.elements[name].addEventListener("input", updatePrediction);
});

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
        const res = await api("/api/incidents", { method: "POST", body: formPayload() });
        dialog.close();
        if (res.allocated) {
            showToast(`${res.incident_id} reported (${res.severity}). Dispatched ${res.allocation.resource_id}, ` +
                      `${res.allocation.distance_km} km away.`);
        } else {
            showToast(`${res.incident_id} reported (${res.severity}). ${res.alert}`, "alert");
        }
        refresh();
    } catch (err) {
        showToast(err.message, "error");
    }
});

refresh();
setInterval(refresh, 5000);
