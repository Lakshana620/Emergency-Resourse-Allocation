# AI-Based Emergency Resource Allocation System

Mini project for 25ADC01 – Artificial Intelligence and Applications.
Predicts incident severity with machine learning, then assigns the best available
resource (ambulance, fire engine, rescue team, relief truck) using an optimization
algorithm, with a live monitoring dashboard.

## Quick start

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

The first run creates `emergency.db` (SQLite) with sample resources and three pending
incidents, and trains the severity model into `model/`. Click **Re-run AI Optimization**
to allocate the pending incidents.

Run the tests:

```bash
python -m pytest -q
```

## How it maps to the report

| Report module (Ch. 4) | File |
|---|---|
| Data Collection (validation) | `app.py` → `validate_incident` |
| Incident Severity Prediction | `severity_model.py` |
| Resource Availability Tracking | `database.py` |
| AI-Based Allocation Optimization | `allocator.py` → `plan_allocations` |
| Dispatch and Notification | `allocator.py` → `run_allocation` (dispatch message logged and stored) |
| Monitoring Dashboard | `templates/index.html`, `static/` |

Workflow: Incident report → severity prediction → resource availability check →
optimization engine → allocation → dispatch notification → dashboard.

## How allocation works

1. Pending incidents are handled in strict priority order: Critical → High → Medium → Low.
2. Within a severity tier, the Hungarian algorithm finds the assignment with the lowest
   total weighted travel distance.
3. Unsuitable resources are excluded (e.g. a relief truck is never sent to a medical call).
   Less ideal but usable units cost extra distance (see `SUITABILITY` in `allocator.py`).
4. Incidents with more casualties get a lower cost, so they win when units are scarce.
5. Incidents with no free suitable resource stay **Pending** and are retried when a new
   incident arrives, a resource is added, or a response is marked complete.

## Severity model

TF-IDF + Logistic Regression over the emergency type, casualty bucket and description.
No real dataset is bundled, so it trains on synthetic records from
`generate_training_data()`. Replace that function with your own historical incident
records to train on real data. A safety rule also forces at least High for 3+ casualties
and Critical for 5+.

## API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/dashboard` | Stats, pending incidents, fleet, recent allocations |
| POST | `/api/incidents` | Report an incident (predicts severity, allocates if possible) |
| POST | `/api/predict` | Preview predicted severity |
| POST | `/api/optimize` | Re-run allocation for all pending incidents |
| POST | `/api/allocations/<id>/complete` | Finish a response, free the resource, re-allocate |
| POST | `/api/resources` | Add a resource |

## Test cases (Chapter 8)

`tests/test_system.py` implements TC01–TC04 plus checks for unsuitable/busy resources,
the severity model and input validation.

## Notes

- Database: SQLite for zero setup. The schema is plain SQL and can move to MySQL.
- Distances are straight-line (haversine). For road distance, plug in a routing API.
- Sample coordinates are around Coimbatore.
