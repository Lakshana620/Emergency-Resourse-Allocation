"""AI-Based Allocation Optimization + Dispatch modules (Chapter 4.1 / 7.4 / 7.5).

Strategy
--------
1. Pending incidents are grouped by severity and handled strictly in priority
   order: Critical -> High -> Medium -> Low.
2. Inside each severity tier the Hungarian algorithm (scipy linear_sum_assignment)
   finds the assignment of incidents to free resources with the minimum total
   weighted travel distance, so a tier is solved optimally, not greedily.
3. Unsuitable resources (e.g. a relief truck for a medical call) are excluded.
   Less-ideal-but-usable resources cost extra distance via a suitability factor.
4. Incidents with more casualties get a lower cost, so they win when resources
   are scarce within the same tier.
5. Whatever cannot be served stays Pending and is retried on the next run
   (new incident, or a resource becoming free).
"""
import logging
import math

import numpy as np
from scipy.optimize import linear_sum_assignment

from database import now_str

log = logging.getLogger("dispatch")

RESOURCE_TYPES = ["Ambulance", "Fire Engine", "Rescue Team", "Relief Truck"]
SEVERITY_RANK = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1}

# Suitability factor per emergency type: lower = better fit. Missing type = unsuitable.
SUITABILITY = {
    "Accident":   {"Ambulance": 1.0, "Rescue Team": 1.2},
    "Fire":       {"Fire Engine": 1.0, "Ambulance": 1.5, "Rescue Team": 1.6},
    "Flood":      {"Rescue Team": 1.0, "Relief Truck": 1.2, "Ambulance": 1.8},
    "Medical":    {"Ambulance": 1.0},
    "Earthquake": {"Rescue Team": 1.0, "Ambulance": 1.2, "Relief Truck": 1.4, "Fire Engine": 1.6},
}

CASUALTY_WEIGHT = 0.25
UNSUITABLE = 1e6


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = p2 - p1
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def plan_allocations(incidents, resources):
    """Pure function: returns a list of (incident, resource, distance_km)."""
    plan = []
    free = list(resources)

    tiers = {}
    for inc in incidents:
        tiers.setdefault(SEVERITY_RANK[inc["severity"]], []).append(inc)

    for rank in sorted(tiers, reverse=True):
        if not free:
            break
        group = tiers[rank]
        cost = np.full((len(group), len(free)), UNSUITABLE)
        dist = np.zeros((len(group), len(free)))

        for i, inc in enumerate(group):
            factors = SUITABILITY.get(inc["emergency_type"], {})
            priority_boost = 1 + CASUALTY_WEIGHT * inc["casualties"]
            for j, res in enumerate(free):
                factor = factors.get(res["resource_type"])
                if factor is None:
                    continue
                d = haversine_km(inc["latitude"], inc["longitude"], res["latitude"], res["longitude"])
                dist[i, j] = d
                cost[i, j] = (d * factor + 0.1) / priority_boost

        rows, cols = linear_sum_assignment(cost)
        used = set()
        for r, c in zip(rows, cols):
            if cost[r, c] >= UNSUITABLE:
                continue
            plan.append((group[r], free[c], float(dist[r, c])))
            used.add(c)
        free = [res for k, res in enumerate(free) if k not in used]

    return plan


def run_allocation(conn):
    """Read pending incidents + available resources, allocate, dispatch, update DB."""
    pending = [dict(r) for r in conn.execute("SELECT * FROM incidents WHERE status = 'Pending'")]
    available = [dict(r) for r in conn.execute("SELECT * FROM resources WHERE status = 'Available'")]

    results = []
    for inc, res, dist in plan_allocations(pending, available):
        message = (
            f"DISPATCH {res['resource_id']} ({res['resource_type']}) -> {inc['incident_id']} "
            f"[{inc['emergency_type']}, {inc['severity']}] at "
            f"({inc['latitude']:.4f}, {inc['longitude']:.4f}). Distance {dist:.1f} km. "
            f"Casualties reported: {inc['casualties']}."
        )
        log.info(message)
        cur = conn.execute(
            "INSERT INTO allocations(incident_id, resource_id, distance_km, assigned_time, message)"
            " VALUES (?,?,?,?,?)",
            (inc["incident_id"], res["resource_id"], round(dist, 2), now_str(), message),
        )
        conn.execute("UPDATE incidents SET status = 'Allocated' WHERE incident_id = ?", (inc["incident_id"],))
        conn.execute("UPDATE resources SET status = 'Busy' WHERE resource_id = ?", (res["resource_id"],))
        results.append({
            "allocation_id": cur.lastrowid,
            "incident_id": inc["incident_id"],
            "resource_id": res["resource_id"],
            "resource_type": res["resource_type"],
            "distance_km": round(dist, 2),
            "message": message,
        })
    conn.commit()
    return results


def complete_allocation(conn, allocation_id):
    """Response finished: free the resource at the incident site, then re-run allocation."""
    alloc = conn.execute(
        "SELECT * FROM allocations WHERE allocation_id = ? AND status = 'Active'", (allocation_id,)
    ).fetchone()
    if alloc is None:
        return None
    inc = conn.execute("SELECT * FROM incidents WHERE incident_id = ?", (alloc["incident_id"],)).fetchone()
    conn.execute("UPDATE allocations SET status = 'Completed' WHERE allocation_id = ?", (allocation_id,))
    conn.execute("UPDATE incidents SET status = 'Resolved' WHERE incident_id = ?", (alloc["incident_id"],))
    conn.execute(
        "UPDATE resources SET status = 'Available', latitude = ?, longitude = ? WHERE resource_id = ?",
        (inc["latitude"], inc["longitude"], alloc["resource_id"]),
    )
    conn.commit()
    return run_allocation(conn)
