"""Test cases from Chapter 8 (TC01-TC04) plus model and validation checks."""
import database as db
import severity_model
from allocator import complete_allocation, plan_allocations, run_allocation

COIMBATORE = (11.0168, 76.9558)


def add_resource(client, rid, rtype, lat, lon):
    res = client.post("/api/resources", json={
        "resource_id": rid, "resource_type": rtype, "latitude": lat, "longitude": lon,
    })
    assert res.status_code == 201
    return res


def report(client, **overrides):
    payload = {
        "emergency_type": "Accident", "latitude": COIMBATORE[0], "longitude": COIMBATORE[1],
        "casualties": 4, "description": "bus collision, people trapped",
    }
    payload.update(overrides)
    return client.post("/api/incidents", json=payload)


# TC01: high severity incident -> nearest suitable resource allocated immediately
def test_tc01_high_severity_gets_nearest_resource(client):
    add_resource(client, "AMB-FAR", "Ambulance", 11.20, 77.20)
    add_resource(client, "AMB-NEAR", "Ambulance", 11.0170, 76.9560)
    body = report(client).get_json()
    assert body["severity"] in ("High", "Critical")
    assert body["allocated"] is True
    assert body["allocation"]["resource_id"] == "AMB-NEAR"


# TC02: multiple simultaneous incidents -> allocated by priority
def test_tc02_simultaneous_incidents_by_priority(client, conn):
    add_resource(client, "AMB-01", "Ambulance", *COIMBATORE)
    db.insert_incident(conn, "Accident", *COIMBATORE, 0, "minor stuck vehicle", "Low")
    critical = db.insert_incident(conn, "Accident", 11.05, 77.0, 6, "people trapped", "Critical")
    results = run_allocation(conn)
    assert [r["incident_id"] for r in results] == [critical]
    pending = conn.execute("SELECT COUNT(*) FROM incidents WHERE status = 'Pending'").fetchone()[0]
    assert pending == 1


# TC03: no available resource -> alert displayed, request queued
def test_tc03_no_resource_queues_request(client):
    body = report(client).get_json()
    assert body["allocated"] is False
    assert "queued" in body["alert"]
    dash = client.get("/api/dashboard").get_json()
    assert dash["stats"]["pending_incidents"] == 1


# TC04: low severity incident is allocated only after high priority is handled
def test_tc04_low_severity_waits_for_high_priority(client, conn):
    add_resource(client, "AMB-01", "Ambulance", *COIMBATORE)
    first = report(client).get_json()                      # takes the only ambulance
    low = db.insert_incident(conn, "Accident", *COIMBATORE, 0, "minor", "Low")
    high = db.insert_incident(conn, "Accident", *COIMBATORE, 3, "injured", "High")

    new = complete_allocation(conn, first["allocation"]["allocation_id"])
    assert [a["incident_id"] for a in new] == [high]
    status = conn.execute("SELECT status FROM incidents WHERE incident_id = ?", (low,)).fetchone()[0]
    assert status == "Pending"


def test_unsuitable_resources_are_never_assigned():
    incidents = [{"incident_id": "X", "emergency_type": "Medical", "severity": "Critical",
                  "casualties": 1, "latitude": 11.0, "longitude": 77.0}]
    trucks = [{"resource_id": "RELF-1", "resource_type": "Relief Truck", "latitude": 11.0, "longitude": 77.0}]
    assert plan_allocations(incidents, trucks) == []


def test_busy_resources_are_excluded(client, conn):
    add_resource(client, "AMB-01", "Ambulance", *COIMBATORE)
    report(client)
    second = report(client).get_json()
    assert second["allocated"] is False


def test_severity_model_sanity():
    high, _ = severity_model.predict_severity("Accident", 5, "people trapped, collapsed structure")
    low, _ = severity_model.predict_severity("Accident", 0, "minor, no injuries")
    assert high == "Critical"
    assert low == "Low"


def test_validation_errors(client):
    assert report(client, emergency_type="Zombie").status_code == 400
    assert report(client, latitude=999).status_code == 400
    assert report(client, casualties=-2).status_code == 400
