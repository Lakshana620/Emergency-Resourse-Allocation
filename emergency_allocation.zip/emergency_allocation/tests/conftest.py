import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@pytest.fixture()
def client(tmp_path, monkeypatch):
    """Fresh, empty database (no seed data) for every test."""
    monkeypatch.setenv("EMERGENCY_DB", str(tmp_path / "test.db"))
    from app import create_app

    app = create_app(seed=False)
    app.testing = True
    return app.test_client()


@pytest.fixture()
def conn(client):
    import database as db

    c = db.get_conn()
    yield c
    c.close()
